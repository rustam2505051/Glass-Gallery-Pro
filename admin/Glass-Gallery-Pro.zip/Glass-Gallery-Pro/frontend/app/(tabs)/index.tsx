// RestArtuz - Premium Home Screen with Dynamic Firebase Data
import React, { useState, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  RefreshControl,
  FlatList,
  Platform,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, {
  useAnimatedScrollHandler,
  useSharedValue,
  useAnimatedStyle,
  interpolate,
  FadeIn,
  FadeInDown,
  FadeInRight,
} from 'react-native-reanimated';

import { useLanguage, useMLText } from '@/src/contexts/LanguageContext';
import { useFirestoreCollection, useBanners, useHomeSections } from '@/src/hooks/useFirestore';
import { useFavorites } from '@/src/hooks/useFavorites';
import { Category, Product, Banner } from '@/src/types';
import { ProductCard } from '@/src/components/ProductCard';
import { CategoryCard } from '@/src/components/CategoryCard';
import { BannerCarousel } from '@/src/components/BannerCarousel';
import { SearchBar } from '@/src/components/SearchBar';
import { SectionHeader } from '@/src/components/SectionHeader';
import { Loading } from '@/src/components/Loading';
import { Colors, Spacing, Typography, BorderRadius, Shadows } from '@/src/constants/theme';
import { DEMO_BANNERS, DEMO_CATEGORIES, DEMO_PRODUCTS, FEATURED_COLLECTIONS } from '@/src/constants/demoData';
import { orderBy, limit, where } from 'firebase/firestore';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { t } = useLanguage();
  const getMLText = useMLText();
  const [refreshing, setRefreshing] = useState(false);
  const scrollY = useSharedValue(0);

  // Firebase data hooks
  const { data: banners, loading: bannersLoading } = useBanners();
  const { data: homeSections, loading: sectionsLoading } = useHomeSections();
  
  const { data: categories, loading: categoriesLoading } = useFirestoreCollection<Category>('categories', [
    where('isActive', '==', true),
    orderBy('order', 'asc'),
    limit(8),
  ]);

  const { data: allProducts, loading: productsLoading } = useFirestoreCollection<Product>('products', [
    where('isActive', '==', true),
  ]);

  const { toggleFavorite, isFavorite } = useFavorites();

  // Use Firebase data or fallback to demo data
  const displayBanners = banners.length > 0 ? banners : DEMO_BANNERS;
  const displayCategories = categories.length > 0 ? categories : DEMO_CATEGORIES;
  const displayProducts = allProducts.length > 0 ? allProducts : DEMO_PRODUCTS;
  
  // Filter products for different sections
  const featuredProducts = useMemo(() => 
    displayProducts.filter(p => p.isFeatured).slice(0, 6), 
    [displayProducts]
  );
  const newProducts = useMemo(() => 
    displayProducts.filter(p => p.isNew).slice(0, 6), 
    [displayProducts]
  );
  const popularProducts = useMemo(() => 
    [...displayProducts].sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0)).slice(0, 6), 
    [displayProducts]
  );

  // Scroll handler
  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  // Animated header styles
  const headerStyle = useAnimatedStyle(() => ({
    opacity: interpolate(scrollY.value, [0, 100], [0, 1]),
    transform: [{ translateY: interpolate(scrollY.value, [0, 100], [-20, 0]) }],
  }));

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 1000));
    setRefreshing(false);
  }, []);

  const handleBannerPress = (banner: Banner) => {
    if (banner.linkType === 'category' && banner.linkId) {
      router.push(`/category/${banner.linkId}`);
    } else if (banner.linkType === 'product' && banner.linkId) {
      router.push(`/product/${banner.linkId}`);
    }
  };

  // Get products for a dynamic section
  const getProductsForSection = useCallback((section: any) => {
    switch (section.type) {
      case 'featured_products':
        return featuredProducts.slice(0, section.limit || 6);
      case 'new_arrivals':
        return newProducts.slice(0, section.limit || 6);
      case 'popular_products':
        return popularProducts.slice(0, section.limit || 6);
      case 'category_products':
        return displayProducts
          .filter(p => p.categoryId === section.categoryId)
          .slice(0, section.limit || 6);
      case 'custom_products':
        // For custom products, you would filter by specific IDs
        return displayProducts.slice(0, section.limit || 6);
      default:
        return [];
    }
  }, [featuredProducts, newProducts, popularProducts, displayProducts]);

  // Render dynamic section
  const renderDynamicSection = (section: any, index: number) => {
    if (section.type === 'categories') {
      return (
        <View key={section.id} style={styles.section}>
          <SectionHeader
            title={getMLText(section.title)}
            icon={section.icon}
            showSeeAll={section.showSeeAll}
            onSeeAll={() => router.push('/(tabs)/categories')}
            delay={300 + index * 100}
          />
          <FlatList
            data={displayCategories.slice(0, section.limit || 8)}
            renderItem={({ item, index: idx }) => (
              <CategoryCard
                category={item}
                onPress={() => router.push(`/category/${item.id}`)}
                getMLText={getMLText}
                index={idx}
              />
            )}
            keyExtractor={(item) => item.id}
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalList}
          />
        </View>
      );
    }

    const products = getProductsForSection(section);
    if (products.length === 0) return null;

    return (
      <View key={section.id} style={styles.section}>
        <SectionHeader
          title={getMLText(section.title)}
          icon={section.icon}
          showSeeAll={section.showSeeAll}
          onSeeAll={() => {
            if (section.categoryId) {
              router.push(`/category/${section.categoryId}`);
            } else {
              router.push('/(tabs)/categories');
            }
          }}
          delay={300 + index * 100}
        />
        <FlatList
          data={products}
          renderItem={({ item, index: idx }) => (
            <View style={styles.productWrapper}>
              <ProductCard
                product={item}
                onPress={() => router.push(`/product/${item.id}`)}
                onFavoritePress={() => toggleFavorite(item.id)}
                isFavorite={isFavorite(item.id)}
                showNewBadge={section.type === 'new_arrivals'}
                index={idx}
              />
            </View>
          )}
          keyExtractor={(item) => `${section.id}-${item.id}`}
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.horizontalList}
        />
      </View>
    );
  };

  // Render content with dynamic sections from Firebase
  const renderContent = () => {
    const hasFirebaseSections = homeSections.length > 0;

    return (
      <View style={styles.content}>
        {/* Hero Banner Carousel */}
        <Animated.View entering={FadeIn.delay(200).duration(600)}>
          <BannerCarousel
            banners={displayBanners}
            onBannerPress={handleBannerPress}
            getMLText={getMLText}
          />
        </Animated.View>

        {/* Search Bar */}
        <SearchBar
          placeholder={t('searchProducts')}
          onPress={() => router.push('/(tabs)/categories')}
          onFilterPress={() => {}}
        />

        {/* Dynamic Sections from Firebase */}
        {hasFirebaseSections ? (
          homeSections.map((section, index) => renderDynamicSection(section, index))
        ) : (
          // Fallback: Show default sections if no Firebase sections
          <>
            {/* Categories Section */}
            <View style={styles.section}>
              <SectionHeader
                title={t('categories')}
                subtitle="Shop by collection"
                showSeeAll
                onSeeAll={() => router.push('/(tabs)/categories')}
                delay={300}
              />
              <FlatList
                data={displayCategories}
                renderItem={({ item, index }) => (
                  <CategoryCard
                    category={item}
                    onPress={() => router.push(`/category/${item.id}`)}
                    getMLText={getMLText}
                    index={index}
                  />
                )}
                keyExtractor={(item) => item.id}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.horizontalList}
              />
            </View>

            {/* Featured Collections */}
            <View style={styles.section}>
              <SectionHeader
                title="Featured Collections"
                icon="✨"
                showSeeAll={false}
                delay={400}
              />
              <FlatList
                data={FEATURED_COLLECTIONS}
                renderItem={({ item, index }) => (
                  <Animated.View entering={FadeInRight.delay(index * 100).duration(400)}>
                    <TouchableOpacity
                      style={styles.collectionCard}
                      onPress={() => router.push(`/category/${item.categoryId}`)}
                      activeOpacity={0.9}
                    >
                      <Image
                        source={{ uri: item.imageUrl }}
                        style={styles.collectionImage}
                        contentFit="cover"
                        transition={300}
                      />
                      <LinearGradient
                        colors={['transparent', 'rgba(5, 5, 5, 0.7)', 'rgba(5, 5, 5, 0.95)']}
                        locations={[0, 0.5, 1]}
                        style={styles.collectionGradient}
                      />
                      <View style={styles.collectionContent}>
                        <View style={styles.collectionBadge}>
                          <Text style={styles.collectionBadgeText}>{item.productCount}+ items</Text>
                        </View>
                        <Text style={styles.collectionTitle}>{getMLText(item.title)}</Text>
                        <Text style={styles.collectionDesc}>{getMLText(item.description)}</Text>
                      </View>
                      <View style={styles.collectionGoldLine} />
                    </TouchableOpacity>
                  </Animated.View>
                )}
                keyExtractor={(item) => item.id}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.horizontalList}
              />
            </View>

            {/* Featured Products */}
            {featuredProducts.length > 0 && (
              <View style={styles.section}>
                <SectionHeader
                  title="Featured"
                  icon="⭐"
                  showSeeAll
                  onSeeAll={() => router.push('/(tabs)/categories')}
                  delay={500}
                />
                <FlatList
                  data={featuredProducts}
                  renderItem={({ item, index }) => (
                    <View style={styles.productWrapper}>
                      <ProductCard
                        product={item}
                        onPress={() => router.push(`/product/${item.id}`)}
                        onFavoritePress={() => toggleFavorite(item.id)}
                        isFavorite={isFavorite(item.id)}
                        index={index}
                      />
                    </View>
                  )}
                  keyExtractor={(item) => item.id}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.horizontalList}
                />
              </View>
            )}

            {/* New Arrivals */}
            {newProducts.length > 0 && (
              <View style={styles.section}>
                <SectionHeader
                  title="New Arrivals"
                  icon="🆕"
                  showSeeAll
                  onSeeAll={() => router.push('/(tabs)/categories')}
                  delay={600}
                />
                <FlatList
                  data={newProducts}
                  renderItem={({ item, index }) => (
                    <View style={styles.productWrapper}>
                      <ProductCard
                        product={item}
                        onPress={() => router.push(`/product/${item.id}`)}
                        onFavoritePress={() => toggleFavorite(item.id)}
                        isFavorite={isFavorite(item.id)}
                        showNewBadge
                        index={index}
                      />
                    </View>
                  )}
                  keyExtractor={(item) => item.id}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.horizontalList}
                />
              </View>
            )}

            {/* Popular / Trending */}
            {popularProducts.length > 0 && (
              <View style={styles.section}>
                <SectionHeader
                  title="Trending Now"
                  icon="🔥"
                  showSeeAll
                  onSeeAll={() => router.push('/(tabs)/categories')}
                  delay={700}
                />
                <FlatList
                  data={popularProducts}
                  renderItem={({ item, index }) => (
                    <View style={styles.productWrapper}>
                      <ProductCard
                        product={item}
                        onPress={() => router.push(`/product/${item.id}`)}
                        onFavoritePress={() => toggleFavorite(item.id)}
                        isFavorite={isFavorite(item.id)}
                        index={index}
                      />
                    </View>
                  )}
                  keyExtractor={(item) => `popular-${item.id}`}
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.horizontalList}
                />
              </View>
            )}
          </>
        )}

        {/* Premium Footer */}
        <View style={styles.footer}>
          <View style={styles.footerLogo}>
            <Text style={styles.footerLogoText}>R</Text>
          </View>
          <Text style={styles.footerTitle}>RestArtuz</Text>
          <Text style={styles.footerSubtitle}>Premium Interior Materials</Text>
          <View style={styles.footerDivider} />
          <Text style={styles.footerCopyright}>© 2025 RestArtuz. All rights reserved.</Text>
        </View>

        {/* Bottom spacer for tab bar */}
        <View style={{ height: 100 }} />
      </View>
    );
  };

  // Show loading while initial data loads
  const isInitialLoading = bannersLoading && categoriesLoading && productsLoading;
  
  if (isInitialLoading && banners.length === 0 && categories.length === 0 && allProducts.length === 0) {
    return <Loading message={t('loading')} />;
  }

  // Open Admin Panel using native navigation
  const openAdminPanel = () => {
    // Navigate to the native admin panel using Expo Router
    router.push('/admin');
  };

  return (
    <View style={styles.container}>
      <StatusBar style="light" />

      {/* Animated Header */}
      <Animated.View style={[styles.header, { paddingTop: insets.top }, headerStyle]}>
        {Platform.OS === 'ios' ? (
          <BlurView intensity={80} tint="dark" style={styles.headerBlur}>
            <HeaderContent router={router} />
          </BlurView>
        ) : (
          <View style={[styles.headerBlur, styles.headerAndroid]}>
            <HeaderContent router={router} />
          </View>
        )}
      </Animated.View>

      {/* Main Scroll Content */}
      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        onScroll={scrollHandler}
        scrollEventThrottle={16}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={onRefresh}
            tintColor={Colors.primary}
            colors={[Colors.primary]}
          />
        }
        contentContainerStyle={{ paddingTop: insets.top }}
      >
        {/* Hero Logo Section */}
        <Animated.View 
          entering={FadeInDown.delay(100).duration(500)}
          style={styles.heroHeader}
        >
          <View style={styles.heroLogoContainer}>
            <LinearGradient
              colors={[Colors.primary, Colors.goldDark]}
              style={styles.heroLogo}
            >
              <Text style={styles.heroLogoText}>R</Text>
            </LinearGradient>
          </View>
          <Text style={styles.heroTitle}>RestArtuz</Text>
          <Text style={styles.heroSubtitle}>Premium Interior Materials</Text>
        </Animated.View>

        {renderContent()}
      </Animated.ScrollView>

      {/* Floating Admin Button */}
      <Animated.View 
        entering={FadeIn.delay(800).duration(400)}
        style={[styles.adminButtonContainer, { bottom: insets.bottom + 100 }]}
      >
        <TouchableOpacity
          style={styles.adminButton}
          onPress={openAdminPanel}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={[Colors.primary, Colors.goldDark]}
            style={styles.adminButtonGradient}
          >
            <Ionicons name="settings" size={20} color={Colors.background} />
            <Text style={styles.adminButtonText}>Admin</Text>
          </LinearGradient>
        </TouchableOpacity>
      </Animated.View>
    </View>
  );
}

// Header Content Component
function HeaderContent({ router }: { router: any }) {
  return (
    <View style={styles.headerContent}>
      <View style={styles.headerLogo}>
        <Text style={styles.headerLogoText}>R</Text>
      </View>
      <Text style={styles.headerTitle}>RestArtuz</Text>
      <TouchableOpacity 
        style={styles.headerIcon}
        onPress={() => router.push('/(tabs)/profile')}
      >
        <Ionicons name="notifications-outline" size={22} color={Colors.primary} />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  
  // Header
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
  },
  headerBlur: {
    overflow: 'hidden',
  },
  headerAndroid: {
    backgroundColor: Colors.glass,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  headerLogo: {
    width: 32,
    height: 32,
    borderRadius: BorderRadius.sm,
    backgroundColor: Colors.primary,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerLogoText: {
    fontSize: 18,
    fontWeight: '800',
    color: Colors.background,
  },
  headerTitle: {
    flex: 1,
    ...Typography.h4,
    color: Colors.textPrimary,
    marginLeft: Spacing.sm,
    fontWeight: '700',
  },
  headerIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },

  // Hero Header
  heroHeader: {
    alignItems: 'center',
    paddingVertical: Spacing.xl,
    paddingTop: Spacing.xxl,
  },
  heroLogoContainer: {
    marginBottom: Spacing.md,
    ...Shadows.goldGlow,
  },
  heroLogo: {
    width: 64,
    height: 64,
    borderRadius: BorderRadius.lg,
    justifyContent: 'center',
    alignItems: 'center',
  },
  heroLogoText: {
    fontSize: 36,
    fontWeight: '800',
    color: Colors.background,
  },
  heroTitle: {
    ...Typography.h1,
    color: Colors.textPrimary,
    fontWeight: '800',
    letterSpacing: -1,
  },
  heroSubtitle: {
    ...Typography.body2,
    color: Colors.textSecondary,
    marginTop: Spacing.xs,
  },

  // Content
  content: {
    flex: 1,
  },
  section: {
    marginBottom: Spacing.xl,
  },
  horizontalList: {
    paddingHorizontal: Spacing.md,
  },
  productWrapper: {
    marginRight: Spacing.md,
  },

  // Collection Cards
  collectionCard: {
    width: 260,
    height: 160,
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    marginRight: Spacing.md,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
    ...Shadows.medium,
  },
  collectionImage: {
    ...StyleSheet.absoluteFillObject,
  },
  collectionGradient: {
    ...StyleSheet.absoluteFillObject,
  },
  collectionContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: Spacing.md,
  },
  collectionBadge: {
    alignSelf: 'flex-start',
    backgroundColor: Colors.goldLight,
    paddingHorizontal: Spacing.sm,
    paddingVertical: 2,
    borderRadius: BorderRadius.xs,
    marginBottom: Spacing.xs,
  },
  collectionBadgeText: {
    ...Typography.overline,
    color: Colors.primary,
    fontSize: 9,
  },
  collectionTitle: {
    ...Typography.h4,
    color: Colors.textPrimary,
    fontWeight: '700',
  },
  collectionDesc: {
    ...Typography.caption,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  collectionGoldLine: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 2,
    backgroundColor: Colors.primary,
    opacity: 0.7,
  },

  // Footer
  footer: {
    alignItems: 'center',
    paddingVertical: Spacing.xxl,
    paddingHorizontal: Spacing.lg,
    marginTop: Spacing.xl,
  },
  footerLogo: {
    width: 48,
    height: 48,
    borderRadius: BorderRadius.md,
    backgroundColor: Colors.surface,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: Spacing.md,
  },
  footerLogoText: {
    fontSize: 24,
    fontWeight: '800',
    color: Colors.primary,
  },
  footerTitle: {
    ...Typography.h3,
    color: Colors.textPrimary,
    fontWeight: '700',
  },
  footerSubtitle: {
    ...Typography.caption,
    color: Colors.textTertiary,
    marginTop: Spacing.xs,
  },
  footerDivider: {
    width: 48,
    height: 2,
    backgroundColor: Colors.border,
    marginVertical: Spacing.lg,
  },
  footerCopyright: {
    ...Typography.caption,
    color: Colors.textTertiary,
  },

  // Admin Button
  adminButtonContainer: {
    position: 'absolute',
    right: Spacing.lg,
    zIndex: 50,
  },
  adminButton: {
    borderRadius: BorderRadius.xl,
    overflow: 'hidden',
    ...Shadows.goldGlow,
  },
  adminButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.xs,
    paddingVertical: Spacing.sm,
    paddingHorizontal: Spacing.md,
  },
  adminButtonText: {
    ...Typography.button,
    color: Colors.background,
    fontWeight: '700',
    fontSize: 13,
  },
});
