# Glass-Gallery-Pro (RestArtuz)

Premium Interior Decoration Materials Catalog App

## Features
- Premium luxury UI with dark theme and gold accents
- Native Admin Panel (Expo Router screens)
- Firebase integration (Auth, Firestore, Storage)
- Gemini AI product description generator
- Multi-language support (UZ, RU, EN)
- Product catalog with categories and banners
- Full CRUD operations for all entities

## Tech Stack
- **Frontend**: Expo React Native (SDK 54)
- **Backend**: FastAPI (for development server)
- **Database**: Firebase Firestore
- **Storage**: Firebase Storage
- **AI**: Google Gemini 2.5 Flash
- **Auth**: Firebase Authentication

## Getting Started

### Install Dependencies
```bash
cd frontend
npm install
```

### Run Development
```bash
npm start
```

### Build Android APK
```bash
npm install -g eas-cli
eas login
eas build --platform android --profile production
```

## Admin Panel
The Admin Panel is built as native Expo Router screens:
- `/admin` - Dashboard
- `/admin/products` - Products CRUD
- `/admin/categories` - Categories CRUD
- `/admin/banners` - Banners CRUD
- `/admin/users` - User Management
- `/admin/orders` - Order Management
- `/admin/settings` - App Settings

Access the Admin Panel by tapping the floating "Admin" button on the Home screen.

## Firebase Setup
Configure your Firebase project credentials in:
- `frontend/app.json` (extra section)
- `frontend/.env` (for development)

## Production Notes
- All data comes directly from Firebase
- No dependency on temporary servers
- APK works standalone for years
- Native navigation (no WebBrowser)
