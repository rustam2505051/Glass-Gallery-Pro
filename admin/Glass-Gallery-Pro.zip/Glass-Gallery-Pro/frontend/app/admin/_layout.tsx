import React from 'react';
import { Stack } from 'expo-router';
import { View, StyleSheet } from 'react-native';
import { theme } from '../../src/constants/theme';

export default function AdminLayout() {
  return (
    <View style={styles.container}>
      <Stack
        screenOptions={{
          headerStyle: {
            backgroundColor: theme.colors.surface,
          },
          headerTintColor: theme.colors.primary,
          headerTitleStyle: {
            fontWeight: 'bold',
            color: theme.colors.text,
          },
          contentStyle: {
            backgroundColor: theme.colors.background,
          },
          animation: 'slide_from_right',
        }}
      >
        <Stack.Screen 
          name="index" 
          options={{ 
            title: 'Admin Dashboard',
            headerShown: true,
          }} 
        />
        <Stack.Screen 
          name="products" 
          options={{ 
            title: 'Products',
            headerShown: true,
          }} 
        />
        <Stack.Screen 
          name="product-edit" 
          options={{ 
            title: 'Edit Product',
            headerShown: true,
            presentation: 'modal',
          }} 
        />
        <Stack.Screen 
          name="categories" 
          options={{ 
            title: 'Categories',
            headerShown: true,
          }} 
        />
        <Stack.Screen 
          name="banners" 
          options={{ 
            title: 'Banners',
            headerShown: true,
          }} 
        />
        <Stack.Screen 
          name="users" 
          options={{ 
            title: 'Users',
            headerShown: true,
          }} 
        />
        <Stack.Screen 
          name="orders" 
          options={{ 
            title: 'Orders',
            headerShown: true,
          }} 
        />
        <Stack.Screen 
          name="settings" 
          options={{ 
            title: 'Settings',
            headerShown: true,
          }} 
        />
      </Stack>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
});
