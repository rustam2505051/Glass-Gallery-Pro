# RestArtuz Test Credentials

## Admin Panel Access
- **URL**: https://restartuz.preview.emergentagent.com/api/admin
- **Email**: rustam2505051@gmail.com
- **Password**: @Rus2505051bek
- **Role**: Super Admin

## Firebase Project
- **Project ID**: restartuz
- **Console**: https://console.firebase.google.com/project/restartuz

## Mobile App Access
- **URL**: https://restartuz.preview.emergentagent.com
- **No authentication required for mobile app browsing**
- **Admin Button**: Floating gold "Admin" button on home screen opens admin panel

## Admin Panel Features (Production-Ready)

### Multi-Language Support
- **Languages**: Uzbek (O'zbek), Russian (Русский), English
- **Language saved permanently** in localStorage
- All UI elements, buttons, forms, notifications translated

### Dashboard
- Real-time statistics from Firestore (Categories, Products, Banners, Orders, Users, Views)
- **Orders Overview Chart** (doughnut chart)
- **Products by Category Chart** (bar chart)
- Recent Orders table
- Recent Products table

### Categories Management
- Full CRUD (Create, Read, Update, Delete)
- Multi-language names (uz/ru/en)
- Firebase Storage image uploads with progress
- Display order control
- Active/Inactive toggle

### Products Management
- Full CRUD with all fields
- Multi-language names and descriptions
- Multiple image upload with **drag & drop sorting**
- Firebase Storage uploads with progress indicators
- Product code, price, currency, stock status
- Size, thickness, material specifications
- Featured/New Arrival tags
- Category assignment

### Banners Management
- Full CRUD with Firebase Storage uploads
- Multi-language titles and subtitles
- Link type (category/product/external URL)
- Display order control
- Active/Inactive toggle

### Sections (Homepage)
- Dynamic section configuration
- Section types: Featured, New Arrivals, Category Products, Popular, Categories
- Product limit control
- Icon selection
- "See All" button toggle

### Orders Management
- View all orders from Firestore
- Search and filter by status
- Order details modal
- Status update (pending/processing/completed/cancelled)
- Delete orders
- Real-time badge counter in sidebar

### Users Management
- Full CRUD for users
- Name, Email, Phone fields
- **Roles**: Admin, Manager, User
- Active/Inactive toggle
- Search functionality

### Settings
- **Company Logo Upload** to Firebase Storage
- Multi-language company name
- WhatsApp Number (auto-generates wa.me link)
- Telegram Username (auto-generates t.me link)
- Phone Numbers (comma-separated)
- Email
- Address
- **Social Links**: Instagram, Facebook, YouTube
- All saved to Firestore

### Mobile Responsive
- Fully responsive on all screen sizes
- Hamburger menu for mobile navigation
- Optimized forms for mobile input

## Technical Notes
- Admin panel uses Firebase Authentication (Email/Password)
- All data stored in Firestore (no demo/mock data)
- All images stored in Firebase Storage
- Real-time updates via Firebase onSnapshot listeners
- Charts powered by Chart.js
- Drag & drop sorting powered by SortableJS
- Toast notifications for all operations
- Loading states and progress indicators throughout
