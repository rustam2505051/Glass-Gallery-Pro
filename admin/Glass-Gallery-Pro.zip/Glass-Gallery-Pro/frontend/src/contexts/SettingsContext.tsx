// Settings Context with Firebase Integration
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../config/firebase';
import { AppSettings, Banner, MultiLangText } from '../types';

// Default settings
const DEFAULT_SETTINGS: AppSettings = {
  companyName: {
    uz: 'RestArtuz',
    ru: 'RestArtuz',
    en: 'RestArtuz',
  },
  companyDescription: {
    uz: 'Premium interyer materiallari',
    ru: 'Премиум материалы для интерьера',
    en: 'Premium Interior Materials',
  },
  logoUrl: '',
  whatsappNumber: '+998901234567',
  whatsappLink: 'https://wa.me/998901234567',
  telegramUsername: '@restartuz',
  telegramLink: 'https://t.me/restartuz',
  phoneNumbers: ['+998901234567'],
  email: 'info@restartuz.com',
  banners: [],
  primaryColor: '#D4AF37',
  accentColor: '#D4AF37',
  enablePricing: true,
  enableSharing: true,
  enableFavorites: true,
};

interface SettingsContextType {
  settings: AppSettings;
  loading: boolean;
  error: Error | null;
}

const SettingsContext = createContext<SettingsContextType>({
  settings: DEFAULT_SETTINGS,
  loading: true,
  error: null,
});

export const useSettings = () => useContext(SettingsContext);

interface SettingsProviderProps {
  children: ReactNode;
}

export function SettingsProvider({ children }: SettingsProviderProps) {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!db) {
      setLoading(false);
      return;
    }

    // Subscribe to settings document
    const unsubscribe = onSnapshot(
      doc(db, 'settings', 'app'),
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          setSettings({
            ...DEFAULT_SETTINGS,
            ...data,
            // Ensure nested objects have defaults
            companyName: data.companyName || DEFAULT_SETTINGS.companyName,
            companyDescription: data.companyDescription || DEFAULT_SETTINGS.companyDescription,
            phoneNumbers: data.phoneNumbers || DEFAULT_SETTINGS.phoneNumbers,
            banners: data.banners || [],
          });
        }
        setLoading(false);
      },
      (err) => {
        console.error('Settings error:', err);
        setError(err as Error);
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, []);

  return (
    <SettingsContext.Provider value={{ settings, loading, error }}>
      {children}
    </SettingsContext.Provider>
  );
}
