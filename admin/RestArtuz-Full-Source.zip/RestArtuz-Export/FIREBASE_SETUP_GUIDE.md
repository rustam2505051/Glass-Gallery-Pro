# 🔥 Firebase Setup Guide - RestArtuz

Complete step-by-step guide to connect Firebase to your RestArtuz application.

## Step 1: Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Add project"
3. Enter project name: **rest-artuz** (or your choice)
4. Disable Google Analytics (optional)
5. Click "Create project"
6. Wait for creation, then click "Continue"

## Step 2: Register Web App

1. In Firebase console, click the **Web icon** `</>`
2. App nickname: **RestArtuz Admin**
3. Don't check Firebase Hosting
4. Click "Register app"
5. **COPY** the Firebase configuration:

```javascript
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project-id",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc"
};
```

6. **SAVE THIS** - you'll need it next

## Step 3: Enable Authentication

1. Go to **Authentication** → **Get started**
2. Click **Sign-in method** tab
3. Enable **Email/Password**
4. Click **Save**

### Create Admin User

1. Go to **Users** tab
2. Click **Add user**
3. Email: `admin@restartuz.com` (your choice)
4. Password: (strong password, minimum 6 characters)
5. Click **Add user**
6. **SAVE YOUR CREDENTIALS** - you'll need them to login

## Step 4: Enable Firestore Database

1. Go to **Firestore Database**
2. Click **Create database**
3. Select **Production mode**
4. Choose location (closest to your users)
5. Click **Enable**

### Set Firestore Security Rules

1. Go to **Rules** tab
2. Replace with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Public read, admin write
    match /categories/{document=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    match /products/{document=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    match /settings/{document=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    // User-specific data
    match /favorites/{document=**} {
      allow read, write: if true; // Allow anonymous for now
    }
    
    match /recentlyViewed/{document=**} {
      allow read, write: if true;
    }
    
    match /searchQueries/{document=**} {
      allow read: if request.auth != null;
      allow write: if true;
    }
  }
}
```

3. Click **Publish**

## Step 5: Enable Firebase Storage

1. Go to **Storage** → **Get started**
2. Select **Production mode**
3. Choose same location as Firestore
4. Click **Done**

### Set Storage Security Rules

1. Go to **Rules** tab
2. Replace with:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    // Public read, admin write
    match /products/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    match /banners/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    match /logos/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null;
    }
  }
}
```

3. Click **Publish**

## Step 6: Configure Mobile App

1. Open: `/app/frontend/src/config/firebase.ts`
2. Replace the config:

```typescript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",           // From Step 2
  authDomain: "YOUR_AUTH_DOMAIN",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_STORAGE_BUCKET",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

## Step 7: Configure Admin Panel

1. Open: `/app/frontend/admin/index.html`
2. Find line ~35 with `firebaseConfig`
3. Replace with same config from Step 2

## Step 8: Test the Setup

### Test Admin Panel

1. Go to: `https://restartuz.preview.emergentagent.com/admin`
2. Login with admin credentials from Step 3
3. If successful, you'll see the dashboard!

### Test Mobile App

1. Go to: `https://restartuz.preview.emergentagent.com`
2. App should load without errors
3. After adding categories/products in admin, they'll appear here

## Step 9: Add Initial Data

In the admin panel:

### Create Categories

1. Click "Categories"
2. Click "+ Add Category"
3. Fill in names (Uzbek, Russian, English)
4. Click "Save"

Example categories:
- Kitchen Backsplash / Кухонный Фартук / Oshxona Artini
- Onyx Texture / Оникс / Oniks
- PVC Panel / ПВХ Панели / PVX Panellar
- Photo Wallpaper / Фотообои / Fotooboylar

### Add Products

1. Click "Products"
2. Click "+ Add Product"
3. Fill all fields:
   - Product code (e.g., KB-001)
   - Select category
   - Names in 3 languages
   - Descriptions
   - Specifications (size, thickness, stock)
   - Upload images
4. Click "Save Product"

### Configure Settings

1. Click "Settings"
2. Fill company information:
   - Company names in 3 languages
   - WhatsApp number (e.g., +998901234567)
   - Telegram username (e.g., @restartuz)
   - Phone numbers
3. Click "Save Settings"

## ✅ Verification Checklist

- [ ] Firebase project created
- [ ] Authentication enabled with admin user
- [ ] Firestore database created with security rules
- [ ] Storage enabled with security rules
- [ ] Mobile app config updated
- [ ] Admin panel config updated
- [ ] Admin login working
- [ ] Categories created
- [ ] Products added
- [ ] Settings configured
- [ ] Mobile app showing data

## 🎉 Success!

Your RestArtuz app is now fully connected to Firebase!

### What Happens Now

✅ **Real-time Sync**: Changes in admin instantly appear in mobile app
✅ **No App Updates**: Add/edit content without rebuilding
✅ **Secure**: Only admins can modify data
✅ **Scalable**: Firebase handles millions of users
✅ **Analytics**: Track views, searches, favorites

## 📱 URLs

**Mobile App**: https://restartuz.preview.emergentagent.com
**Admin Panel**: https://restartuz.preview.emergentagent.com/admin

## 🆘 Troubleshooting

### "Firebase not configured" error
- Check that you replaced ALL placeholder values
- Verify no typos in config
- Config must match in both files

### Admin login fails
- Verify Email/Password auth is enabled
- Check admin user exists in Firebase Console
- Try password reset in Firebase Console

### Images not uploading
- Check Storage rules are set
- Verify file size under 10MB
- Check browser console for errors

### Data not syncing
- Verify Firestore rules are set
- Check browser console for permission errors
- Ensure you're logged in as admin

## 🔒 Security Notes

**Current Setup**: Development-friendly
- Public can read all data
- Only authenticated users can write

**For Production**:
- Add user roles in Firestore
- Implement stricter write rules
- Enable App Check
- Set up Firebase security monitoring

## 📊 Firebase Free Tier Limits

- **Firestore**: 1GB storage, 50K reads/day, 20K writes/day
- **Storage**: 5GB storage, 1GB downloads/day
- **Authentication**: Unlimited

This is enough for testing and small to medium catalogs.

## 🚀 Next Steps

After Firebase is connected:
1. Add your product catalog
2. Upload product images
3. Configure company settings
4. Test on mobile devices
5. Build APK for distribution
6. Start Phase 2 (AI features, advanced search, etc.)

---

**Need Help?** Check Firebase Console → Usage for monitoring, and Console logs for errors.
